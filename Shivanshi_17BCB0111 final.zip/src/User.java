import java.sql.*;
import java.io.*;

public class User {
	 public int csv() {
	 
	   try {
	    PrintWriter pw= new PrintWriter(new File("C:\\Users\\91981\\Desktop\\software_project.csv"));
	    StringBuilder sb=new StringBuilder();
	 
	    sb.append("Name");
	    sb.append(","); 
	    sb.append("Credit Card Number");
	    sb.append(",");
	    sb.append("Amount");
	    sb.append(",");
	    sb.append("Date_Of_Payment");
	    sb.append(",");
	    sb.append("Pending_Months");
	    sb.append("\r\n");
	    
	    Connection connection=null;
	    Db_Connection obj_DB_Connection=new Db_Connection();
	    connection=obj_DB_Connection.getConnection();
	    ResultSet rs=null;
	 
	    String query="select * from client";
	    PreparedStatement ps=connection.prepareStatement(query);
	    rs=ps.executeQuery();
	 
	    while(rs.next()){
	     sb.append(rs.getString("name"));
	     sb.append(","); 
	     sb.append(rs.getString("creditcard_no"));
	     sb.append(",");
	     sb.append(rs.getString("amount"));
	     sb.append(",");
	     sb.append(rs.getString("date_of_payment"));
	     sb.append(",");
	     sb.append(rs.getString("pending_months"));
	     sb.append("\r\n");
	    }
	 
	    pw.write(sb.toString());
	    pw.close();
	    //System.out.println("Finished");
	    return 1;
	   } catch (Exception e) {
	    // TODO: handle exception
	   } 
	   return 0;
	 }
	 public static void main(String[] args)
	 {
		 User obj = new User();
			int j = obj.csv();
			if(j==1)
			{
				System.out.println("Successfully Generated in specified path !!");
			}
			else
			{
				System.out.println("Please check !!");
			}
	 }
	}